"""Chess tool implementations, decoupled from the agent that registers them.

Every function here takes the HTTP client explicitly instead of reading it off
an agent, so the same code can run in the agent process or inside the sandbox
beside the server it talks to.
"""

from __future__ import annotations

import base64
import json
from typing import Any

import httpx

CHESS_PORT = 8000

# A model-written snippet runs unattended in the sandbox, and a 2-ply search
# over an open position is already hundreds of HTTP calls. Without a ceiling a
# runaway loop blocks the whole agent forever, since `Environment.execute`
# waits indefinitely by default.
RUN_PYTHON_TIMEOUT_SECONDS = 120


def _request_state(
    client: httpx.Client, method: str, endpoint: str, **kwargs: Any
) -> dict[str, Any]:
    """Make one chess API request and validate its JSON response."""

    response = client.request(method, endpoint, **kwargs)
    try:
        payload = response.json()
    except ValueError as exc:
        raise RuntimeError(
            f"Chess server returned non-JSON ({response.status_code})."
        ) from exc
    if response.status_code >= 400:
        detail = (
            payload.get("detail", payload) if isinstance(payload, dict) else payload
        )
        raise ValueError(str(detail))
    if not isinstance(payload, dict):
        raise RuntimeError("Chess server response must be a JSON object.")
    return payload


def _simulate_move(client: httpx.Client, arguments: str) -> str:
    """New tool: inspect FEN or simulate one ply without changing the game.

    Takes the raw JSON arguments of one tool call and returns the observation
    to send back, so a bad argument or a server error reaches the model as a
    recoverable ``<chess_error>`` instead of ending the run.
    """
    # TODO(Part 3.3.b): Parse the arguments, call the provided
    # /api/simulate endpoint with fen and optional move, and return its JSON.
    # Catch any errors raised by the tool and return an error message between
    # `<chess_error></chess_error>` for the agent to address. Cover malformed
    # JSON arguments, arguments that are not an object, a missing or
    # non-string fen, a non-string move, a position or move the server rejects,
    # and a transport failure.
    try:
        parsed = json.loads(arguments)
    except (json.JSONDecodeError, TypeError) as exc:
        return (
            f"<chess_error>Could not parse the arguments to `simulate_move` as "
            f"JSON: {exc}. Send them again as a valid JSON object."
            "</chess_error>"
        )

    if not isinstance(parsed, dict):
        return (
            f"<chess_error>The arguments to `simulate_move` must be a JSON "
            f"object, got {type(parsed).__name__}.</chess_error>"
        )

    fen = parsed.get("fen")
    if not isinstance(fen, str) or not fen.strip():
        return (
            "<chess_error>`simulate_move` requires a `fen` string: a complete "
            "six-field FEN describing the position to inspect.</chess_error>"
        )

    move = parsed.get("move")
    if move is not None and not isinstance(move, str):
        return (
            f"<chess_error>`move` must be a string in UCI notation or null, "
            f"got {type(move).__name__}.</chess_error>"
        )

    payload: dict[str, Any] = {"fen": fen.strip()}
    # The server's request model forbids unknown keys and takes `move` as
    # optional, so an omitted move is left out rather than sent as empty.
    if isinstance(move, str) and move.strip():
        payload["move"] = move.strip()

    try:
        # The server owns the rules here too: it rejects a malformed or
        # impossible FEN, an illegal move, and a move in a terminal position,
        # each as a 400 that `_request_state` re-raises as a ValueError.
        state = _request_state(client, "POST", "/api/simulate", json=payload)
    except ValueError as exc:
        return f"<chess_error>{exc}</chess_error>"
    except RuntimeError as exc:
        return f"<chess_error>{exc}</chess_error>"
    except httpx.HTTPError as exc:
        return (
            f"<chess_error>Could not reach the chess server "
            f"({type(exc).__name__}: {exc}).</chess_error>"
        )

    return json.dumps(state)


def _play_move(client: httpx.Client, arguments: str) -> str:
    """Existing tool: play one move as White and return the resulting state.

    Takes the raw JSON arguments of one tool call. Returns the new state, or a
    `<chess_error>` observation if the move could not be played.
    """
    # TODO(3.1.b): Parse the arguments and POST {"move": <uci move>} to
    # /api/move. Return its JSON object. Catch any errors raised by the
    # tool and return an error message between `<chess_error></chess_error>`
    # for the agent to address. Cover malformed JSON arguments, arguments
    # that are not an object, a missing or non-string fen, a non-string move,
    # a position or move the server rejects, and a transport failure.
    try:
        parsed = json.loads(arguments)
    except (json.JSONDecodeError, TypeError) as exc:
        return (
            f"<chess_error>Could not parse the arguments to `play_move` as "
            f"JSON: {exc}. Send them again as a valid JSON object."
            "</chess_error>"
        )

    if not isinstance(parsed, dict):
        return (
            f"<chess_error>The arguments to `play_move` must be a JSON object, "
            f"got {type(parsed).__name__}.</chess_error>"
        )

    move = parsed.get("move")
    if not isinstance(move, str) or not move.strip():
        return (
            "<chess_error>`play_move` requires a `move` string in UCI "
            "notation, for example e2e4.</chess_error>"
        )

    try:
        # The server owns the rules: it rejects an illegal move, a move out of
        # turn, and a move in a finished game, each as a 400 that
        # `_request_state` re-raises as a ValueError carrying its detail.
        state = _request_state(client, "POST", "/api/move", json={"move": move.strip()})
    except ValueError as exc:
        return f"<chess_error>{exc}</chess_error>"
    except RuntimeError as exc:
        return f"<chess_error>{exc}</chess_error>"
    except httpx.HTTPError as exc:
        return (
            f"<chess_error>Could not reach the chess server "
            f"({type(exc).__name__}: {exc}).</chess_error>"
        )

    return json.dumps(state)


def _run_python(env: Any, port: int, arguments: str) -> str:
    """New tool: run Python with access to the existing registered tools.

    The snippet runs inside the sandbox, which already has the tool
    implementations and the chess server, so code the model wrote never
    executes in the agent process.
    """
    # TODO(3.4): parse the arguments and run the code in the
    # sandbox with the registered tools available by name.
    #
    # `/opt/assignment/sandbox_python.py` is a script on the `env` sandbox
    # that has access to the same tool definitions in this file. Use it to run
    # the code that the model produced as an argument to the run_python tool.
    # The script accepts two positional arguments -- `port` and a base64-encoded
    # string of code (to prevent issues with quoting). Implement this tool
    # call.
    #
    # The script prints one JSON object with `stdout`, `stderr`, and `error`
    # from running the code -- return that string as it is.
    #
    # A non-zero returncode means the sandbox itself failed, not the model's
    # code. Report `exception_info` or `stderr` as a <chess_error>.
    #
    # Return <chess_error>{message}</chess_error> if there are issues like type
    # mismatches or parsing failures.
    try:
        parsed = json.loads(arguments)
    except (json.JSONDecodeError, TypeError) as exc:
        return (
            f"<chess_error>Could not parse the arguments to `run_python` as "
            f"JSON: {exc}. Send them again as a valid JSON object."
            "</chess_error>"
        )

    if not isinstance(parsed, dict):
        return (
            f"<chess_error>The arguments to `run_python` must be a JSON "
            f"object, got {type(parsed).__name__}.</chess_error>"
        )

    code = parsed.get("code")
    if not isinstance(code, str) or not code.strip():
        return (
            "<chess_error>`run_python` requires a `code` string holding the "
            "snippet to run.</chess_error>"
        )

    # Base64 keeps quoting, newlines, and shell metacharacters in the model's
    # code from being reinterpreted on the way to the sandbox.
    encoded = base64.b64encode(code.encode("utf-8")).decode("ascii")
    try:
        result = env.execute(
            ["python", "/opt/assignment/sandbox_python.py", str(port), encoded],
            shell=False,
            timeout=RUN_PYTHON_TIMEOUT_SECONDS,
        )
    except Exception as exc:
        return (
            f"<chess_error>Could not run the snippet in the sandbox "
            f"({type(exc).__name__}: {exc}).</chess_error>"
        )

    # A non-zero code means the runner itself failed. A snippet that raised is
    # still a successful run: its exception is reported in the JSON `error`.
    if result.get("returncode") != 0:
        detail = (
            result.get("exception_info")
            or result.get("stderr")
            or result.get("output")
            or "no output"
        )
        # A timeout comes back as returncode -1 with the reason in
        # `exception_info`. Say what to do about it: the model cannot see the
        # ceiling it just hit, and will otherwise resend the same snippet.
        if "timeout" in str(detail).lower() or "timed out" in str(detail).lower():
            return (
                f"<chess_error>The snippet did not finish within "
                f"{RUN_PYTHON_TIMEOUT_SECONDS} seconds and was stopped. Nothing "
                "it did was applied. Search fewer candidates or fewer plies, "
                "and avoid unbounded loops.</chess_error>"
            )
        return (
            f"<chess_error>The sandbox runner failed "
            f"(exit {result.get('returncode')}): {detail}</chess_error>"
        )

    # The runner writes its JSON object, and only that, to the real stdout.
    return result.get("stdout") or result.get("output") or ""


def _invoke_skill(skills: dict[str, dict[str, str]], arguments: str) -> str:
    """Existing tool: load one skill's instructions into the conversation."""
    # TODO(3.5): parse the arguments and return the named skill's content.
    # Return <chess_error>{message}</chess_error> if there are issues like type
    # mismatches or parsing failures.
    try:
        parsed = json.loads(arguments)
    except (json.JSONDecodeError, TypeError) as exc:
        return (
            f"<chess_error>Could not parse the arguments to `invoke_skill` as "
            f"JSON: {exc}. Send them again as a valid JSON object."
            "</chess_error>"
        )

    if not isinstance(parsed, dict):
        return (
            f"<chess_error>The arguments to `invoke_skill` must be a JSON "
            f"object, got {type(parsed).__name__}.</chess_error>"
        )

    name = parsed.get("name")
    if not isinstance(name, str) or not name.strip():
        return (
            "<chess_error>`invoke_skill` requires a `name` string naming the "
            "skill to load.</chess_error>"
        )

    skill = (skills or {}).get(name.strip())
    if skill is None:
        available = ", ".join(sorted(skills or {})) or "none"
        return (
            f"<chess_error>Unknown skill {name!r}. Available skills: "
            f"{available}.</chess_error>"
        )

    # The catalog in the prompt carries only each skill's one-line summary;
    # this is the half that was withheld until the model asked for it.
    return skill["content"]


def _game_state(client: httpx.Client, reset: bool = False) -> dict:
    """Read the live game, or start a new one and read the opening position."""

    method, endpoint = ("POST", "/api/reset") if reset else ("GET", "/api/state")
    return _request_state(client, method, endpoint)
